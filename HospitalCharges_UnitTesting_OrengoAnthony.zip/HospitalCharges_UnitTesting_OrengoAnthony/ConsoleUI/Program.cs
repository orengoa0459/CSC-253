﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalLibrary;
/*
* Date 09.06.2020
* CSC 153
* Anthony Orengo
* Program description: This program calculates the total amount of
* hospital charges for each patient.The results will be displayed 
* to the user and saved in a list(patientBill)for future reference.
*
*******************************************************************
* Revised Date: 10.21.2020
* 
* 1. Program has been revised and now includes unit testing. Unit
* testing will be used to ensure the calculations within the 
* program are correct. All test will be conducted using Xunit
* unit testing tool.
* 
* 2. Program has also been revised by using code folding for 
* better code organization..
* ******************************************************************
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Variables,Objects & Sentinels
            //Declare variables
            string input = "";           
            double totalDailyCharges = 0.0;
            double totalMiscCharges = 0.0;
            double totalHospitalCharges = 0.0;
            //Declare and initialize sentinel for main menu
            bool menuLoop = false;
            //Create patient object
            Patient patientName = new Patient();
            //Create patient list for storage
            List<Patient> patientBill = new List<Patient>();
            //Create ConsoleKeyInfo object to recieve keyboard input for main menu
            ConsoleKeyInfo keyboard = new ConsoleKeyInfo();
            #endregion

            #region Main Menu
            do
            {
                //Display program title
                Console.WriteLine(HospitalLibrary.StandardMessages.DisplayMainTitle());
                //Display main menu
                Console.Write(HospitalLibrary.StandardMessages.MainMenu());
                keyboard = Console.ReadKey();
                switch (keyboard.Key)               
                {
                    case ConsoleKey.D1:   
                        //Enter number of overnight days
                        GetHospitalCharges.GetStayCharges(ref totalDailyCharges, ref totalMiscCharges, menuLoop, input);                        
                        break;
                    case ConsoleKey.D2:
                        //Enter misc charges
                        GetHospitalCharges.GetMiscCharges(ref totalMiscCharges, menuLoop, input);                       
                        break;
                    case ConsoleKey.D3:
                        //Calculate total hospital bill
                        GetHospitalCharges.GetTotalCharges(ref totalHospitalCharges, ref totalDailyCharges, ref totalMiscCharges,ref patientBill,patientName, input);                       
                        break;
                    case ConsoleKey.D4:                        
                        //Display patient data from List
                        DisplayHospitalCharges.HospitalBillTracker(ref totalHospitalCharges, ref totalDailyCharges, ref totalMiscCharges,ref patientBill, patientName, input);                        
                        break;
                    case ConsoleKey.Escape:
                        //Ends program
                        menuLoop = true;
                        break;
                    default:
                        //Display invalid input
                        Console.WriteLine("\n" + HospitalLibrary.StandardMessages.InvalidInput());
                        Console.WriteLine(HospitalLibrary.StandardMessages.DisplayPressEnter());
                        Console.ReadLine();
                        Console.Clear();
                        break;
                }
                Console.Clear();
            } while (menuLoop == false);
            #endregion
        }
    }
}