﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Xunit.Extensions;
using Xunit.Abstractions;
namespace HospitalLibrary.Tests
{
    public class CalculatorHospitalChargesTests
    {
        #region Test One: Stay Charges
        [Fact]
        public void StayCharges_ValuesShouldCalculateStayCharges()
        {
            //Tests calculation for hospital overnight charges

            //Arrange
            double expected = 700;

            //Act
            double actual = CalculateHospitalCharges.CalcStayCharges(0, 2, 350);

            //Assert
            Assert.Equal(expected, actual);
        }
        #endregion End Test One

        #region Test Two: Miscellaneous Charges
        [Fact]
        public void MiscCharges_ValuesShouldCalculateStayCharges()
        {
            //Tests calculation for hospital misc charges

            //Arrange
            double expected = 1450;

            //Act
            double actual = CalculateHospitalCharges.CalcMiscCharges(0, 200, 300,450,500);

            //Assert
            Assert.Equal(expected, actual);

        }
        #endregion End Test Two

        #region Test Three: Total Charges
        [Fact]
        public void TotalCharges_ValuesShouldCalculateStayCharges()
        {
            //Tests calculation for total hospital charges

            //Arrange
            double expected = 2150;

            //Act
            double actual = CalculateHospitalCharges.CalcTotalCharges(0, 700, 1450);

            //Assert
            Assert.Equal(expected, actual);
        }
        #endregion End Test Three

    }//End CalculatorHospitalChargesTests

}//End namespace HospitalLibrary.Tests
