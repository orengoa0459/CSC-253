﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalLibrary
{
    public class Patient
    {
        #region Fields
        //Fields
        private string _firstName;
        private string _lastName;
        private double _totalCharges;
        private string _strName;
        private string _strBill;
        #endregion

        #region Default Constructor
        //Default Constructor
        public Patient()
        {
            FirstName = "";
            LastName = "";
            TotalCharges = 0.0;
            StrName = "";
            StrBill = "";
        }
        #endregion

        #region Custom Constructor
        //Parameterized Constructor
        public Patient(string strName, string firstName, string lastName, string strBill, double totalCharges)
        {
            StrName = strName;
            FirstName = firstName;
            LastName = lastName;
            StrBill = strBill;
            TotalCharges = totalCharges;
        }
        #endregion

        #region Properties
        //Properties
        public string FirstName
        {
            get
            {
                return _firstName;

            }
            set
            {
                _firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return _lastName;

            }
            set
            {
                _lastName = value;
            }
        }
        public double TotalCharges
        {
            get
            {
                return _totalCharges;

            }
            set
            {
                _totalCharges = value;
            }
        }
        public string StrName
        {
            get
            {
                return _strName;

            }
            set
            {
                _strName = value;
            }
        }

        public string StrBill
        {
            get
            {
                return _strBill;

            }
            set
            {
                _strBill = value;
            }
        }
        #endregion
    }//End Patient Class

}//namespace HospitalLibrary
