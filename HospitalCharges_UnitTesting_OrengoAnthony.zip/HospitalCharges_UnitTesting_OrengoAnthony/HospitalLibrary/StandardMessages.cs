﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalLibrary
{
    #region Standard Messages
    public class StandardMessages
    {
        //**The Standard messages go in order based on the program

        //Display main menu title
        public static string DisplayMainTitle()
        {
            return "*****************************\n" +
                   "*   Hospital Bill Charges   *\n" +
                   "*****************************";
        }
        //Display main menu
        public static string MainMenu()
        {
            return "1. Enter Hospital Stay\n" +
                "2. Enter Misc Charges\n" +
                "3. Calculate Total Charges\n" +
                "4. Display Patient Tracker\n" +
                "Esc. Exit\n\n" +
                "Make a selection --> ";               
        }
        public static string DisplayOvernightTitle()
        {
            return "*****************************\n" +
                   "*   Hospital Stay Charges   *\n" +
                   "*****************************";
        }
        public static string DisplayMedicationTitle()
        {
            return "*****************************\n" +
                   "*     Medication Charges    *\n" +
                   "*****************************";
        }
        public static string DisplaySurgicalTitle()
        {
            return "*****************************\n" +
                   "*     Surgical Charges      *\n" +
                   "*****************************";
        }
        public static string DisplayLabFeeTitle()
        {
            return "*****************************\n" +
                   "*      Lab Fee Charges      *\n" +
                   "*****************************";
        }
        public static string DisplayRehabTitle()
        {
            return "*****************************\n" +
                   "*   Rehabilitation Charges  *\n" +
                   "*****************************";
        }

        //Display enter patient medication cost
        public static string GetMedicationCost ()
        {
            return "Enter patients medication cost--> ";
        }
        //Display enter surgical cost
        public static string GetSurgicalCost()
        {
            return "Enter patients surgical cost--> ";
        }
        //Display enter lab fee
        public static string GetLabFee()
        {
            return "Enter patients lab fee--> ";
        }
        //Display rehab cost
        public static string GetRehabCost()
        {
            return "Enter patients rehabilitation cost--> ";
        }
        public static string GetDailyRate()
        {
            return "Enter hospitals daily rate--> ";
        }
        //Display enter overnight days
        public static string GetOvernightStay()
        {
            return "Enter amount of overnight days--> ";
        }
        //Display hospital bill to user
        public static string DisplayHospitalBill(ref double totalHospitalCharges, ref double totalDailyCharges, ref double totalMiscCharges)
        {
            return $"\n*********************\n " +
                $"    Hospital Bill\n" +
                $"*********************\n" +
                $"Hospital stay charge: {totalDailyCharges}\n" +
                $"Misc charges: {totalMiscCharges} \n" +
                $"Total: {totalHospitalCharges}";
        }
        //Display enter patients first name
        public static string DisplayEnterPatientFName()
        {
            return "\nEnter Patients First Name --> ";
        }
        //Display enter patients last name
        public static string DisplayEnterPatientLName()
        {
            return "Enter Patients Last Name --> ";
        }
        //Display enter patients last name
        public static string InvalidPatientLName()
        {
            return "You need to enter the patients first and last name!\n" +
                "If the patient does not have a name enter the defualt name below.\n\n" +
                "First name John/Jane\n" +
                "Last name: Doe";
        }
        //Display patient tracker title
        public static string DisplayTrackerTitle()
        {
            return "*****************************\n" +
                   "*      Patient Tracker      *\n" +
                   "*****************************";
        }
        //Displays press enter to user
        public static string DisplayPressEnter()
        {
            return "Press Enter...";
        }
        //Displays invalid input to user
        public static string InvalidInput()
        {
            return "Invalid input! Try again...";
        }
    }
    #endregion End of Standard Messages

}//End namespace HospitalLibrary
