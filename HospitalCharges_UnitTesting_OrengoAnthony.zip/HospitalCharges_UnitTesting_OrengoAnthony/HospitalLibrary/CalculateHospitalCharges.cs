﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalLibrary
{
    public class CalculateHospitalCharges
    {
        #region Calculate Stay Charges (Days)
        //Calculate hospital stay charges
        public static double CalcStayCharges(double totalDailyCharges,int days, double DAILYRATE)
        {
            return totalDailyCharges = days * DAILYRATE;
        }
        #endregion End Calculate Stay Charges

        #region Calculate Stay Charges(Hours)
        //Calculate hospital misc charges
        public static double CalcStayCharges(double totalDailyCharges,double hours, double DAILYRATE)
        {
            return totalDailyCharges = hours * DAILYRATE;
        }
        #endregion End Calculate Stay Charges(Hours)

        #region Calculate Misc Charges
        public static double CalcMiscCharges(double totalMiscCharges, double medication,double surgicalCharge, double labCharge,double rehabCharge)
        {
            return totalMiscCharges = medication + surgicalCharge + labCharge + rehabCharge;
        }
        #endregion Calculate Misc Charges

        #region Calculate Total Charges
        //Calculate total hospital charges
        public static double CalcTotalCharges(double totalHospitalCharges,double  totalDailyCharges, double totalMiscCharges)
        {
            return totalHospitalCharges = totalDailyCharges + totalMiscCharges;
        }
        #endregion End Calculate Total Charges

    }//End CalculateHospitalCharges

}//End namspace HospitalLibrary
