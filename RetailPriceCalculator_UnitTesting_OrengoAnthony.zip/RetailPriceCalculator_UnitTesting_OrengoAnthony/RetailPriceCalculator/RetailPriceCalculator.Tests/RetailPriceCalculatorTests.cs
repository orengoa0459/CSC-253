﻿using RetailLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
namespace RetailPriceCalculator.Tests
{
    public class RetailPriceCalculatorTests
    {

        //Install xunit
        //Install xunit.runner.console
        //Install xunit.runner.visualstudio
        [Fact]
        public void MarkupPrice_ValuesShouldCalculateMarkupPrice()
        {
            //Tests calculation for markup price using the wholesale price and markup percentage

            //Arrange
            decimal expected = 1.0m;

            //Act
            decimal actual = Calculator.MarkupPrice(0.0m, 10.0m, .1m);

            //Assert
            Assert.Equal(expected, actual);
        }
        [Fact]
        public void RetailPrice_ValuesShouldCalculateRetailPrice()
        {
            //Tests calculation for total retail price adding the wholesale price and markup price
            //Arrange
            decimal expected = 11.0m;

            //Act
            decimal actual = Calculator.CalculateTotalCost(0.0m, 10.0m, 1.0m);

            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
