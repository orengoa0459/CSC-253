﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
namespace RetailLibrary
{
    public class CalculateRetailPrice
    {
        public static void CalculateTotalPrice()
        {
            //Clear current screen
            Console.Clear();
            //Declare variables---------------------------------             
            string input = "";
            decimal wholeSale = 0.0m; ;
            decimal markUpPercent = 0.0m; ;
            decimal percent = 0.0m; ;
            decimal markupTotal = 0.0m;
            decimal total = 0.0m; ;
            //Loop sentinels
            bool wholeSaleLoop = false;
            bool MarkupPercentLoop = false;
            //===================================================
            do
            {
                //Display title to user
                Console.WriteLine(StandardMessages.DisplayTitle());
                //Get wholesale price from user
                Console.Write("Enter wholesale price --> ");
                input = Console.ReadLine();
                if (decimal.TryParse(input, out wholeSale))
                {
                    wholeSaleLoop = true;
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayInvalidOption());
                    Console.ReadLine();
                    Console.Clear();
                }
            } while (wholeSaleLoop == false);
            do
            {
                //Display title to user
                Console.WriteLine(StandardMessages.DisplayTitle());
                //Get markup percent from user
                Console.Write("Enter markup percent --> ");
                input = Console.ReadLine();
                if (decimal.TryParse(input, out markUpPercent))
                {
                    MarkupPercentLoop = true;
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayInvalidOption());
                    Console.ReadLine();
                    Console.Clear();
                }
            } while (MarkupPercentLoop == false);            
            //---------------------------------------------------------------------------------
            //Converts markUpPercent input to percentage format
            percent = markUpPercent / 100m;
            Console.WriteLine(StandardMessages.DisplayResultsToUser());
            //Determines the markup price and calculates the total retail price            
            Console.WriteLine("\nMarkup Price: " + Calculator.MarkupPrice(markupTotal, wholeSale, percent).ToString("C", CultureInfo.CurrentCulture) +
                "\nRetail Cost: " + Calculator.CalculateTotalCost(total, wholeSale, markupTotal).ToString("C", CultureInfo.CurrentCulture) +
                "\n\nTotal Cost: " + (Calculator.MarkupPrice(markupTotal, wholeSale, percent) +
                Calculator.CalculateTotalCost(total, wholeSale, markupTotal)).ToString("C", CultureInfo.CurrentCulture));     
            Console.ReadLine();
        }
    }
}
