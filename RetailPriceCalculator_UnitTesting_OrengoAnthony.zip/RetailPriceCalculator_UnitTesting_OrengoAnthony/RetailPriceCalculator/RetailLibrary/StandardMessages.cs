﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
namespace RetailLibrary
{
    public class StandardMessages
    {
        //Display main menu
        public static string DisplayMainMenu()
        {
            return "***************************************\n" +
                   "*             Main Menu               *\n" +
                   "***************************************\n" +
                   "* 1. Whole Sale Calculator            *\n" +
                   "* Esc. Exit                           *\n" +
                   "*                                     *\n" +
                   "***************************************\n\n" +

                   "Make a selection --> ";
        }
        public static string DisplayTitle()
        {
            return "***************************************\n" +
                   "*         Wholesale Calculator        *\n" +
                   "***************************************\n";
        }
        public static string DisplayResultsToUser()
        {
            return "***************************************\n" +
                   "*         Wholesale Calculator        *\n" +
                   "***************************************\n" +
                   "Summary: ";
                     
        
        }
        //Display invalid option to user
        public static string DisplayInvalidOption()
        {
            return "\n\nInvalid Option! Press Enter and Try Again!";
        }
    }
}
