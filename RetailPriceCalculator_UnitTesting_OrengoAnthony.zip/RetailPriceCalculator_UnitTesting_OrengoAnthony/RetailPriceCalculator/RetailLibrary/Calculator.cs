﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;
namespace RetailLibrary
{
    public class Calculator
    {
        public static decimal MarkupPrice(decimal markupTotal, decimal wholeSale,decimal percent)
        {
            
            return markupTotal = wholeSale * percent;
        }
        public static decimal CalculateTotalCost(decimal total,decimal  wholeSale,decimal markupTotal)
        {
            
            return total = wholeSale + markupTotal;
        }
    }
}
